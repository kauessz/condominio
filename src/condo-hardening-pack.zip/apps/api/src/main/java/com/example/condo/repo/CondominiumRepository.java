package com.example.condo.repo;

import com.example.condo.entity.Condominium;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface CondominiumRepository extends JpaRepository<Condominium, Long> {
    @Query("select c from Condominium c where c.tenantId = :t")
    List<Condominium> findAllByTenant(@Param("t") String tenantId);
}
