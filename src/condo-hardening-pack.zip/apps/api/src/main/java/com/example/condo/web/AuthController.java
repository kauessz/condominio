package com.example.condo.web;

import com.example.condo.security.JwtUtils;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/auth")
public class AuthController {

    @Value("${app.jwt.secret}") private String secret;
    @Value("${app.jwt.issuer}") private String issuer;
    @Value("${app.jwt.expirationMinutes}") private Integer expiration;

    public record LoginReq(String email, String password) {}

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody LoginReq req) {
        String role = req.email().contains("admin") ? "ADMIN" : "MANAGER";
        String token = JwtUtils.createToken(req.email(), role, issuer, secret, expiration);
        return ResponseEntity.ok(Map.of("token", token, "role", role));
    }
}
