package com.example.condo.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.parameters.HeaderParameter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class OpenApiConfig {
    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .components(new Components())
                .info(new Info().title("Condo SaaS API").version("v1"))
                .addParametersItem(new HeaderParameter()
                        .name("X-Tenant-ID")
                        .description("Identificador do condomínio (tenant)")
                        .required(false));
    }
}
