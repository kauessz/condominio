package com.example.condo.web;

import com.example.condo.entity.Condominium;
import com.example.condo.repo.CondominiumRepository;
import com.example.condo.tenant.TenantContext;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/condominiums")
public class CondominiumController {
    private final CondominiumRepository repo;
    public CondominiumController(CondominiumRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Condominium> list() {
        return repo.findAllByTenant(TenantContext.get());
    }

    @PostMapping
    @PreAuthorize("hasAnyRole('MANAGER','ADMIN')")
    public Condominium create(@RequestBody Condominium c) {
        c.setTenantId(TenantContext.get());
        return repo.save(c);
    }
}
